# currencyConverter
I have developed a currency converter with the help of an api and i have also made a responsive and attractive website using css properties and also with this converter any currency of any country with their respective code can be converted
this currency converter does also represent the flags when the following currency name is clicked in the dropdown menu which is also created and further by selecting the appropriate country currencies in "from " and "to " block then the grant button is clicked for displaying the current currency code converter 
